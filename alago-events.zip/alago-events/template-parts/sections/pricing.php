<?php
/**
 * Pricing section. Three Customizer-editable packages.
 *
 * @package Alago_Events
 */

$kicker = get_theme_mod( 'alago_pricing_kicker', __( 'Investment', 'alago-events' ) );
$title  = get_theme_mod( 'alago_pricing_title', __( 'Planning Packages', 'alago-events' ) );
$intro  = get_theme_mod( 'alago_pricing_intro', '' );
?>
<section class="ae-section ae-section--cream ae-pricing" id="pricing">
	<div class="ae-container">
		<?php alago_events_section_head( $kicker, $title, $intro ); ?>

		<div class="ae-pricing__grid">
			<?php for ( $n = 1; $n <= 3; $n++ ) : ?>
				<?php
				$p_title    = get_theme_mod( "alago_price_{$n}_title", '' );
				$p_amount   = get_theme_mod( "alago_price_{$n}_amount", '' );
				$p_unit     = get_theme_mod( "alago_price_{$n}_unit", '' );
				$p_features = get_theme_mod( "alago_price_{$n}_features", '' );
				$p_badge    = get_theme_mod( "alago_price_{$n}_badge", '' );
				if ( ! $p_title ) {
					continue;
				}
				$features = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $p_features ) ) );
				$classes  = 'ae-price ae-reveal' . ( $p_badge ? ' ae-price--featured' : '' );
				?>
				<div class="<?php echo esc_attr( $classes ); ?>"<?php echo $p_badge ? ' data-badge="' . esc_attr( $p_badge ) . '"' : ''; ?>>
					<h3><?php echo esc_html( $p_title ); ?></h3>
					<div class="ae-price__amount"><?php echo esc_html( $p_amount ); ?> <small><?php echo esc_html( $p_unit ); ?></small></div>
					<?php if ( $features ) : ?>
						<ul>
							<?php foreach ( $features as $feature ) : ?>
								<li><?php echo esc_html( $feature ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
					<a class="ae-btn <?php echo $p_badge ? 'ae-btn--solid' : ''; ?>" href="#contact"><?php esc_html_e( 'Enquire', 'alago-events' ); ?></a>
				</div>
			<?php endfor; ?>
		</div>
	</div>
</section>
